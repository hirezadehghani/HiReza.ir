<x-form.section>
<button type="submit"
    class="btn py-3 px-4 btn-primary">
    {{ $slot }}
</button>
</x-form.section>
