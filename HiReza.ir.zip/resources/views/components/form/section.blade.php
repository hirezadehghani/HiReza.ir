<div class="form-group">
{{$slot}}
</div>